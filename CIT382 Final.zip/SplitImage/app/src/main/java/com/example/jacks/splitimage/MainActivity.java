package com.example.jacks.splitimage;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.media.Image;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private static final String TAG = "Activity";
    private static int ROW_COUNT;
    private static int COL_COUNT;

    public static ArrayList<Bitmap> tiledImage;
    public int xCoord;
    public int yCoord;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void tilePicture(View view) {
        Log.d(TAG, "tilePicture: started");
        ImageView image1 = (ImageView) findViewById(R.id.imgImage1);
        ImageView image2 = (ImageView) findViewById(R.id.imgImage2);

        switch(view.getId()){
            case R.id.btnTile1:
                ROW_COUNT = 3;
                COL_COUNT = 3;
                tileImage(image1, ROW_COUNT, COL_COUNT);
                break;
            case R.id.btnTile2:
                ROW_COUNT = 4;
                COL_COUNT = 4;
                tileImage(image2, ROW_COUNT, COL_COUNT);
                break;
            default:
                throw new RuntimeException("Unknown Button");
        }
    }

    public void tileImage(ImageView image, int rowSize, int colSize) {
        Log.d(TAG, "tileImage: started");
        int tileHeight, tileWidth;

        tiledImage = new ArrayList<>();

        //ArrayList<Bitmap> tiledImage = new ArrayList<Bitmap>();
        BitmapDrawable drawable = (BitmapDrawable) image.getDrawable();
        Bitmap bitmap = drawable.getBitmap();
        Bitmap scaledBitmap = Bitmap.createScaledBitmap(bitmap, bitmap.getWidth(), bitmap.getHeight(), true);
        tileHeight = bitmap.getHeight() / rowSize;
        tileWidth = bitmap.getWidth() / colSize;

        yCoord = 0;
        for (int r = 0; r < rowSize; r++) {
            xCoord = 0;
            for (int c = 0; c < colSize; c++) {
                tiledImage.add(Bitmap.createBitmap(scaledBitmap, xCoord, yCoord, tileWidth, tileHeight));
                xCoord += tileWidth;
            }
            yCoord += tileHeight;
        }

        //Toast.makeText(this, "num pics = " +tiledImage.size(), Toast.LENGTH_SHORT).show();
        Intent intent = new Intent(getApplicationContext(), TiledActivity.class);

        Bundle extras = new Bundle();
        extras.putInt("rowCount", ROW_COUNT);
        extras.putInt("colCount", COL_COUNT);
        //extras.putParcelableArrayList(tiledImage);
        intent.putExtras(extras);

        Log.d(TAG, "tileImage: going to start the tiledActivity");
        this.startActivity(intent);
    }
}

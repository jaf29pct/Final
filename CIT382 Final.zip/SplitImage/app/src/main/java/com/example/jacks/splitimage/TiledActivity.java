package com.example.jacks.splitimage;

import android.content.ClipData;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.view.menu.MenuView;
import android.util.Log;
import android.view.DragEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ArrayAdapter;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;

public class TiledActivity extends AppCompatActivity {
    private static final String TAG = "Problem";
    private GridLayout gridLayout;
    private List<Integer> loc = new ArrayList<>();
    private List<Bitmap> original;
    private static int nRows;
    private static int nCols;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tiled);

        Log.d(TAG, "onCreate: Tiled activity started");
        gridLayout = (GridLayout) findViewById(R.id.grdImage);
        gridLayout.setUseDefaultMargins(true);
        Intent intent = getIntent();

        Bundle extras = intent.getExtras();
        nRows = extras.getInt("rowCount");
        nCols = extras.getInt("colCount");
        gridLayout.setRowCount(nRows);
        gridLayout.setColumnCount(nCols);

        final LayoutInflater layoutInflater = LayoutInflater.from(this);

        //Toast.makeText(this, "r = " + , Toast.LENGTH_SHORT).show();
        original = (ArrayList<Bitmap>)MainActivity.tiledImage.clone();
        for (int i = 0; i < MainActivity.tiledImage.size(); i++) {
            loc.add(i);
            //original.add(i);
            Log.d(TAG, "onCreateL: " + loc);
            Log.d(TAG, "onCreateO: " + original);
        }

        Collections.shuffle(MainActivity.tiledImage);
        //Log.d(TAG, "Rows: " + nRows + "= " + gridLayout.getRowCount());
        //Log.d(TAG, "Cols: " + nCols + "= " + gridLayout.getColumnCount());

        Log.d(TAG, "ShuffledSplitter: " + "-------------------------");
        Log.d(TAG, "NotShuffled: " + original);
        Log.d(TAG, "Shuffled: " + MainActivity.tiledImage);
        gridLayout.setOnDragListener(new DragListener());

        for(int i : loc){
            View view = layoutInflater.inflate(R.layout.grid_item, gridLayout, false);
            ImageView imageView = view.findViewById(R.id.imgItem);
            imageView.setImageBitmap(MainActivity.tiledImage.get(loc.get(i)));
            view.setOnLongClickListener(new LongPressListener());
            gridLayout.addView(view);
        }
    }

    class DragListener implements View.OnDragListener{
        //@Override
        public boolean onDrag(View v, DragEvent event) {
            final View view = (View) event.getLocalState();
            final int index = calculateNewIndex(event.getX(), event.getY());
            switch (event.getAction()) {
                case DragEvent.ACTION_DRAG_LOCATION:
                    if (view == v) return true;
                    gridLayout.removeView(view);
                    gridLayout.addView(view, index);
                    break;
                case DragEvent.ACTION_DROP:
                    view.setVisibility(View.VISIBLE);
                    break;
                case DragEvent.ACTION_DRAG_ENDED:
                    if (!event.getResult()) {
                        view.setVisibility(View.VISIBLE);
                    }

                    Log.d(TAG, "ShuffledNext: " + MainActivity.tiledImage);
                    if(MainActivity.tiledImage.equals(original)){
                        Toast toast = Toast.makeText(getApplicationContext(),"Win Test", Toast.LENGTH_SHORT);
                        toast.show();
                        picture(gridLayout);
                    }
                    break;
            }
            return true;
        }
    }

    class LongPressListener implements View.OnLongClickListener {
        @Override
        public boolean onLongClick(View view) {
            final ClipData data = ClipData.newPlainText("", "");
            View.DragShadowBuilder shadowBuilder = new View.DragShadowBuilder(view);
            view.startDrag(data, shadowBuilder, view, 0);
            view.setVisibility(View.INVISIBLE);
            return true;
        }
    }

    private int calculateNewIndex(float x, float y) {
        final float cellWidth = gridLayout.getWidth() / gridLayout.getColumnCount();
        final int column = (int)(x / cellWidth);

        final float cellHeight = gridLayout.getHeight() / gridLayout.getRowCount();
        final int row = (int)Math.floor(y / cellHeight);

        int index = row * gridLayout.getColumnCount() + column;
        if (index >= gridLayout.getChildCount()) {
            index = gridLayout.getChildCount() - 1;
        }
        Log.d(TAG, "calculateNewIndex: " + index);

        return index;
    }

    public void picture(View view) {
        GridLayout grid = findViewById(R.id.grdImage);
        Animation animation1 = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.picture);
        grid.startAnimation(animation1);
    }
}
